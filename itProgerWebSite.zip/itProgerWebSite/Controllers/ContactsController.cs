﻿using Microsoft.AspNetCore.Mvc;

namespace itProgerWebSite.Controllers
{
    public class ContactsController : Controller
    {
        public IActionResult Index() // contacts/about
        {
            return View();
        }
    }
}
