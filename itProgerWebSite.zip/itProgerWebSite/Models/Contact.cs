﻿namespace itProgerWebSite.Models
{
    public class Contact
    {
        public string Name { get; set; }

        public string Surname { get; set; }

        public int Age { get; set; }
        public string Email { get; set; }
        public string Message { get; set; }
    }
}
